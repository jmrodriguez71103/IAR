import socket
import json

with open('data.json') as file:
    data = json.load(file)

mi_socket = socket.socket()
mi_socket.connect( ('localhost', 15000) )

serialize = json.dumps(data)

mi_socket.send(serialize.encode())
#mi_socket.send(data.encode())
respuesta = mi_socket.recv(1024)

#with open('data.json', 'w') as file:
#    json.dump(self.respuesta, file)

print (respuesta.decode())
mi_socket.close()
